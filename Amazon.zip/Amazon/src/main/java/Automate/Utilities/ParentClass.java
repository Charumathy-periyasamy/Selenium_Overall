package Automate.Utilities;

public class ParentClass {

}
