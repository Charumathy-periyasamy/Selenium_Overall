package ApiAssignment_IBM.ApiAssignment_IBM;

import java.util.HashMap;

public class Payload_HashMap {

	static HashMap<String,String> hm = new HashMap<String,String>();
	
    
	public static HashMap<String, String> hashMapPayload()
	{
		hm.put("name", "hashmapuser");
		hm.put("department", "E&I");
		

	return hm;
	}
	
}
