package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.ParentClass;

public class CheckOutPage extends ParentClass {

	WebDriver driver;
	public CheckOutPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

@FindBy(css="input[placeholder='Select Country']")
WebElement countryTextBox;

@FindBy(xpath="//button[@class='ta-item list-group-item ng-star-inserted']/span[contains(text(),' India')]")
List<WebElement> listedOptions;

@FindBy(css="a[class='btnn action__submit ng-star-inserted']")
WebElement placeOrderButton;

public void selectCountryInDropdown(String country) throws InterruptedException
{
	countryTextBox.sendKeys(country);
	Thread.sleep(6000);

for(WebElement listedOption : listedOptions)
 {
	
	 if(listedOption.getText().contentEquals("India"))
	 {
		 System.out.println("Listeddoption : " + listedOption.getText());
		listedOption.click();
	 }
 }  

	
}

public ConfirmationPage clickPlaceOrder() throws InterruptedException
{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,document.body.scrollHeight)", "");
	Thread.sleep(4000);
	placeOrderButton.click();
	
	ConfirmationPage placeOrderPage = new ConfirmationPage(driver);
	return placeOrderPage;

}
}
