package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.ParentClass;

public class ProductCatalogue extends ParentClass {

	
	WebDriver driver;
	
	
	public ProductCatalogue(WebDriver driver) {
		super(driver);
		   this.driver = driver;
		   System.out.println("driver: " + driver);
		   PageFactory.initElements(driver, this);	}

@FindBy(xpath="//div[@class=\"card-body\"]")
List<WebElement> Products;



By ProductsBy = By.xpath("//div[@class='card-body']");
By addToCart = By.cssSelector(".card-body button:last-of-type");
By spinner = By.cssSelector(".ng-animating");
By toastMessage = By.cssSelector("#toast-container");

	
	public List<WebElement> getProductList() 
	{
		System.out.println("driv3r : "+ driver );

		waitUntilTheElementToAppear(ProductsBy);
		//System.out.println("products: " + Products);
		return Products;
	}
	
	public WebElement getProductByName(String productName) 
	{
		
	WebElement filteredProduct = getProductList().stream().filter(product -> product.findElement(By.xpath("h5/b")).getText().equals(productName)).findFirst().orElse(null);
	return filteredProduct;
	}
	
	public void addToCart(String productName) {
		
		getProductByName(productName).findElement(addToCart).click();
		waitUnitilTheElementToDisapper(spinner);
		waitUntilTheElementToAppear(toastMessage);
		
		
	}
	
	
	
}
