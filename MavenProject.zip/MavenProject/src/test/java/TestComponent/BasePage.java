package TestComponent;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import PageObjects.LoadingPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BasePage {
	
 public WebDriver driver;
 public LoadingPage loadingPage;
	public WebDriver initializeBrowser() throws IOException
	{
	
		System.out.println("entered into initialize browser");
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir") +  "\\src\\main\\java\\Resources\\GlobalData.properties");
		prop.load(fis);
		
	String browserName = System.getProperty("browser") !=null ? System.getProperty("browser") :  prop.getProperty("browser");

		if(browserName.contains("chrome"))
		{
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			if(browserName.contains("headless"))
			{
				options.addArguments("headless");
				
			}
			
			driver = new ChromeDriver(options);
		}
		
		driver.manage().window().setSize(new Dimension(1440,900));
		return driver;
		
	}
	
	@BeforeMethod
	public LoadingPage launchApplication() throws IOException
	{
		driver = initializeBrowser();
	 loadingPage = new LoadingPage(driver);
		
   loadingPage.goToUrl();
return loadingPage;

	}
	
	@AfterMethod
	public void tearDown()
	{
		driver.close();
	}
	
	
	
	public List<HashMap<String, String>> getJsonDataToMap(String filePath) throws IOException
	{
	// TO read the json data into string
		
		String jsonData =	FileUtils.readFileToString(new File(filePath));

// convert string into map
		ObjectMapper mapper = new ObjectMapper();
		
		
		TypeReference<List<HashMap<String, String>>> typeRef 
		  = new TypeReference<List<HashMap<String, String>>>() {};
		  
		  
	List<HashMap<String, String>> inputData = mapper.readValue(jsonData, typeRef);
	
	return inputData;
		
		
	
	}
	
	public String takeScreenshot( String TestcaseName, WebDriver driver) throws IOException
	{
		TakesScreenshot ts = (TakesScreenshot)driver;
	File source =	ts.getScreenshotAs(OutputType.FILE);
	File destination = new File(System.getProperty("user.dir") + "//screenshots//" + TestcaseName + ".png");
	FileUtils.copyFile(source, destination);
	return System.getProperty("user.dir") + "//reports//" + TestcaseName + ".png";
	
	}

}
