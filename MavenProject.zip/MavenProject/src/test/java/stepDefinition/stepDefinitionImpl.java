package stepDefinition;

import java.io.IOException;

import org.junit.Assert;

import PageObjects.CartPage;
import PageObjects.CheckOutPage;
import PageObjects.ConfirmationPage;
import PageObjects.LoadingPage;
import PageObjects.OrdersPage;
import PageObjects.ProductCatalogue;
import TestComponent.BasePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class stepDefinitionImpl extends BasePage {
	 public LoadingPage loadingPage;
	 public ProductCatalogue productCatalogue;
	 public CheckOutPage checkOutPage;
		public ConfirmationPage  confirmationPage;
		public OrdersPage ordersPage;
		String orderId;
	
@Given("User landed on the ecommerse login page")
public LoadingPage User_landed_on_the_ecommerse_login_page() throws IOException
{
	return loadingPage = launchApplication();
	// return loadingPage;sssss
}

@Given("^Login to the ecommerse website using username (.+) and password (.+)$")
public void Login_to_the_ecommerse_website_using_username_and_password(String username, String password)
{
	 productCatalogue =	loadingPage.action(username,password);
}

@When("^Add the product (.+) into the cart$")
public void Add_the_product_into_the_cart(String productName)
{
	productCatalogue.addToCart(productName);
}

@And("^Verify the product (.+) in the confirmation page and check it out$")
public void Verify_the_product_in_the_confirmation_page_and_check_it_out(String productName)
{
	CartPage cartPage =	productCatalogue.clickCart();
	boolean cartProduct = cartPage.verifyProductDisplay(productName);
	Assert.assertTrue(true);
	 checkOutPage = cartPage.checkout();
	System.out.println("going to enter the then statement");
}

@Then("Place the order and fetch the order id")
public void Place_the_order_and_fetch_the_order_id() throws InterruptedException
{
	checkOutPage.selectCountryInDropdown("India");
	 confirmationPage =	checkOutPage.clickPlaceOrder();
 orderId =	confirmationPage.getOrderId();
	//String orderId = driver.findElement(By.xpath("//td[@class='box']/table/tbody/tr/td/table/tbody/tr[3]/td/label")).getText();

System.out.println("Order ID: " + orderId);
System.out.println("split using | 0:" + orderId.split(" ")[1].trim());

	
}

	
@Then("{string} error should get display")
public void Incorrect_email_or_password_error_should_get_display(String expectedErrorMessage) throws InterruptedException
{
	String actualErrorMessage =  loadingPage.incorrectEmailValidation();
	System.out.println("actualErrorMessage:  "+actualErrorMessage);
	Thread.sleep(4000);
	Assert.assertEquals(expectedErrorMessage, actualErrorMessage);

}

}
