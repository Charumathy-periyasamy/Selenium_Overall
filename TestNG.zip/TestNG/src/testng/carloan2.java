package testng;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class carloan2 {

	
	 @AfterSuite public void afterSuite() {
	  System.out.println("Aftersutie - carloan2"); }
	
	
	
	@Test(groups= {"Smoke"})
	public void barloan2Vr2loan2()
	{
		System.out.println("barloan2vr2loan2");
	}
	
	@Test(groups = {"Smoke"})
	public void carloan2vr3loan2()
	{
		System.out.println("carloan2vr3loan2");
	}
	
	  @BeforeSuite public void beforeSuite() {
	  System.out.println("Beforesutie - carloan2"); }
	 
}
