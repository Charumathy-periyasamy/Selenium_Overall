package TestCases;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import TestComponent.BasePage;
import TestComponent.Retry;
import io.github.bonigarcia.wdm.WebDriverManager;
import junit.framework.Assert;

public class AppiumTest extends BasePage{
	ExtentReports extentReport;

	@Test(retryAnalyzer = Retry.class)
	public void AppiumTest1() throws IOException
	{
	
		loadingPage.action("myemail@gmail.com", "earthAa1@");

		Assert.assertEquals("ghijaf", "uygihu");
	//	takeScreenshot("AppiumTest1");
		System.out.println("Appiumtest1");
		
		
	}
	
	/*
	@BeforeTest
	public void extendReport()
	{

		String extendReportPath = System.getProperty("user.dir")+"\\reports\\indexm.html";
		ExtentSparkReporter extendSpark = new ExtentSparkReporter(extendReportPath);
		extendSpark.config().setDocumentTitle("TestResults");
		extendSpark.config().setReportName("e-commers result");
		
		
	 extentReport = new ExtentReports();
		extentReport.attachReporter(extendSpark);
		extentReport.setSystemInfo("Tester", "Charumathy");
		
}   */
}
