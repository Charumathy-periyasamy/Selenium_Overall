package Automate.TestComponent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Automate.PageObject.LandingPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BasePage {
	
	public WebDriver driver;
	
	public WebDriver initiliazieBrowser()
	{
		System.out.println("inside the InitializeBrowserMethod");
		WebDriverManager.chromedriver().setup();

		driver = new ChromeDriver();

		driver.manage().window().maximize();
		return driver;

	}
	
	public LandingPage launchApplication()
	{
		LandingPage landingPage = new LandingPage();
		driver.get("https://www.amazon.in/");
		return landingPage;
	}

}
