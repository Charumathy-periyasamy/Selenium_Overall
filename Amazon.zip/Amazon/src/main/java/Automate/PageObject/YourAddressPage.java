package Automate.PageObject;

public class YourAddressPage {

}
