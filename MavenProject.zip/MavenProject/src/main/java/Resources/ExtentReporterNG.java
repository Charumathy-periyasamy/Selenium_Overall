package Resources;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public  class ExtentReporterNG {
 
 
	public static ExtentReports ExtentReportsData()
	{
		
		String extendReportPath = System.getProperty("user.dir")+"\\reports\\index.html";
		ExtentSparkReporter extendSpark = new ExtentSparkReporter(extendReportPath);
		extendSpark.config().setDocumentTitle("TestResults");
		extendSpark.config().setReportName("e-commers result");
		
		
	ExtentReports  extentReport = new ExtentReports();
		extentReport.attachReporter(extendSpark);
		extentReport.setSystemInfo("Tester", "Charumathy");
		return extentReport;
		
	}
	
}
