package TestCases;

import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PageObjects.CartPage;
import PageObjects.ProductCatalogue;
import TestComponent.BasePage;
import junit.framework.Assert;

public class ErrorValidation extends BasePage {

	@Test(dataProvider="getData")
	public void invalidLoginValidation(HashMap<String, String> input) throws IOException, InterruptedException
	{
	  String ProductName = "ZARA COAT 3";
	
	
	  loadingPage.action(input.get("email"), input.get("password"));
	String errorMessage =  loadingPage.incorrectEmailValidation();
	System.out.println("error message:  "+errorMessage);
	Thread.sleep(4000);
	Assert.assertEquals("Incorrect email or password.", errorMessage);
	
	}
	
	@Test
	public void invalidProductValidatione()
	{
		String ProucdName = "ZARA COAT 3";
		ProductCatalogue productCatalogue = loadingPage.action("myemail@gmail.com", "earthAa1@");
	WebElement filteredProduct =	productCatalogue.getProductByName(ProucdName);
	productCatalogue.addToCart(ProucdName);
	
	CartPage cartPage = productCatalogue.clickCart();
boolean actualProduct =	cartPage.verifyProductDisplay("ZARA COAT 33");
	
	Assert.assertFalse(actualProduct);	
		
		
	}
	
	@DataProvider
	public Object[][] getData()
	{
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("email", "zyz@gmail.com");
		map.put("password", "zyz");
		

		HashMap<String, String> map1 = new HashMap<String, String>();
		map1.put("email", "xyz@gmail.com");
		map1.put("password", "zyz");
		
		return new Object[][] {{map},{map1}};
	}
	
}

