package log4j;

//import org.apache.log4j.LogManager;
//import org.apache.log4j.Logger;

public class Log4j {

	//static Logger log = LogManager.getLogger(Log4j.class.getName());
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   	
	}

}
