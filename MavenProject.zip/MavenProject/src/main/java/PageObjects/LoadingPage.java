package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import utilities.ParentClass;

/**
 * Hello world!
 *
 */
public class LoadingPage extends ParentClass

{
	WebDriver driver;
	
	public LoadingPage(WebDriver driver){
		super(driver);
	   this.driver = driver;
	   PageFactory.initElements(driver, this);
		
	}
    
	
	
	@FindBy(xpath="//input[@id=\"userEmail\"]")
	WebElement userEmail;
	

	@FindBy(xpath="//*[@id=\"userPassword\"]")
	WebElement passwordElement;
	
	@FindBy(css="input#login")
	WebElement submit;
	
	@FindBy(css="div[class*='toast-message']")
	WebElement errorAlert;
	
public ProductCatalogue action(String email, String password)
{
	userEmail.sendKeys(email);
	passwordElement.sendKeys(password);
	submit.click();
	
	ProductCatalogue productCatalogue = new ProductCatalogue(driver);
 return productCatalogue;
}



public void goToUrl()


{
	driver.get("https://rahulshettyacademy.com/client");
}


public String incorrectEmailValidation()
{
	String errorMessage = errorAlert.getText();
	return errorMessage;
}

}

	
