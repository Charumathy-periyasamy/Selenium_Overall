package TestCases;

import org.testng.annotations.Test;

public class SeleniumTest {


	@Test
	public void seleniumTest1()
	{
		System.out.println("seleniumtest1");
	}
	
	@Test
	public void seleniumTest2()
	{
		System.out.println("seleniumtest2");
	}
	
	
}
