import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowsAuthenticationPopup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\ELCOT\\\\Documents\\\\Grid\\\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
			
		driver.get("https://admin:admin@the-internet.herokuapp.com/");
		driver.manage().window().maximize();
driver.findElement(By.linkText("Basic Auth")).click();
		
		
	}

}
