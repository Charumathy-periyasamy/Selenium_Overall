package Automate.TestCases;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import Automate.PageObject.LandingPage;
import Automate.TestComponent.BasePage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class executeTest extends BasePage {

public	 String perfumeName = "Nivea";
public	 String productName = "Nivea Deodorant, Protect & Care for Women, 150ml";
public  String partialNameOfProduct = "Protect & Care for Women";
public String contenOfProductUrl = "Nivea-Protect-Care-Deodorant-150ml";
public String fullName = "Charumathy P";
public String mobileNumber = "7358488271";
public String pinCode ="600019";
public String addrLine1 = "No.51A/52, kanakar street";
public String addrLine2 = "Theradi, Thiruvottiyur";
public String passsword ="earthAa1@";


//	public static void main(String[] args) throws InterruptedException {
	
	@Test
    public void exe() throws InterruptedException {

		initiliazieBrowser();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1000));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
		LandingPage landingPage = launchApplication();

		driver.findElement(By.cssSelector("input#twotabsearchtextbox"))
				.sendKeys(Keys.chord(Keys.SHIFT, "women perfumes"));
		driver.findElement(By.id("nav-search-submit-text")).click();

		js.executeScript("window.scrollBy(0,500)");
		Thread.sleep(10000);
		WebElement k = driver.findElement(By.xpath("//div[@id='brandsRefinements']/ul/li[last()]/span/div/a"));
		Actions a = new Actions(driver);
		a.moveToElement(k).click(k).build().perform();

		Thread.sleep(3000);
		List<WebElement> perfumeMainList = driver
				.findElements(By.xpath("//div[@id='brandsRefinements']/ul/li/span/a/span"));
		System.out.println(perfumeName);
		Thread.sleep(5000);
		try {
			perfumeMainList.stream().filter(perfume -> perfume.getText().contentEquals(perfumeName))
					.forEach(s -> a.moveToElement(s).click().build().perform());
		} catch (StaleElementReferenceException e)

		{
			e.printStackTrace();
		}

		System.out.println("productName : " + productName);
		List<WebElement> niveaProducts = driver
				.findElements(By.cssSelector("span[class='a-size-base-plus a-color-base a-text-normal']"));

		for (WebElement product : niveaProducts) {
			if (product.getText().contains(partialNameOfProduct)) {
				js.executeScript("arguments[0].scrollIntoView(true);", product);
				product.click();
			}
		}

		Set<String> windows = driver.getWindowHandles();
		Iterator<String> s = windows.iterator();
		while (s.hasNext()) {
			String parentWindow = s.next();
			String childWindow = s.next();
			driver.switchTo().window(childWindow);
		}

		wait.until(ExpectedConditions.urlContains(contenOfProductUrl));
		boolean v = driver.getCurrentUrl().contains(contenOfProductUrl);
		System.out.println(driver.getCurrentUrl());
		Assert.assertTrue(v, "Successfully clicked the nivea product");

		driver.findElement(By.cssSelector("#add-to-cart-button")).click();

		Assert.assertTrue(driver.findElement(By.cssSelector("div#NATC_SMART_WAGON_CONF_MSG_SUCCESS")).isDisplayed());

		driver.findElement(By.xpath("//a[contains(text(),'Go to Cart')]")).click();

		String productinCart = driver
				.findElement(
						By.xpath("//div[@class='sc-list-item-content']//descendant::span[@class='a-truncate-cut']"))
				.getText();

		System.out.println("actualproductname: " + productName);
		System.out.println("expectedproductna: " + productinCart);

		Assert.assertEquals(productName, productinCart);

		WebElement accountAndLists = driver
				.findElement(By.xpath("//div[@class='layoutToolbarPadding']/a[@id='nav-link-accountList']"));

		a.moveToElement(accountAndLists).build().perform();

		driver.findElement(
				By.xpath("//div[@id='nav-al-your-account']/a/span[contains(text(),'Your Account')]/parent::a")).click();

		driver.findElement(By.xpath("//span[@class='a-color-secondary'][contains(text(),'address')]")).click();

		String pageTitle = driver.getTitle();

		if (pageTitle.contains("Sign")) {
			WebElement emailTextBox = driver.findElement(By.xpath("//input[@type='email' and @name='email']"));
			emailTextBox.click();
			emailTextBox.sendKeys(mobileNumber);
			driver.findElement(By.cssSelector("span#continue")).click();
			WebElement passwordTextBox = driver.findElement(By.name("password"));
			passwordTextBox.click();
			passwordTextBox.sendKeys(passsword);
			driver.findElement(By.cssSelector("#signInSubmit")).click();

		}

		driver.findElement(By.cssSelector("#ya-myab-plus-address-icon")).click();

		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressFullName']")).sendKeys(fullName);
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPhoneNumber']"))
				.sendKeys(mobileNumber);
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPostalCode']")).sendKeys(pinCode);
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressLine1']"))
				.sendKeys(addrLine1);
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressLine2']"))
				.sendKeys(addrLine2);
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressCity']"));

		WebElement addAddressButton = driver
				.findElement(By.xpath("//span[@id='address-ui-widgets-form-submit-button-announce']"));
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,200)");
		a.moveToElement(addAddressButton).click().build().perform();

		String addressSaves = driver.findElement(By.cssSelector(".a-alert-heading")).getText();
		Assert.assertEquals(addressSaves, "Address saved");

		driver.findElement(By.xpath("//div[@class='a-row a-spacing-micro'][1]/div[2]/div/span")).click();

		boolean deleteConfirmationPopup = driver.findElement(By.cssSelector(".a-popover-wrapper")).isDisplayed();
		Assert.assertTrue(deleteConfirmationPopup);

		WebElement deleteButton = driver
				.findElement(By.xpath("//div[@class='a-popover-wrapper']/descendant::span[contains(text(),'Yes')]"));
		a.moveToElement(deleteButton).click().build().perform();
		String addressDeeletedMessage = driver.findElement(By.xpath("//h4[@class='a-alert-heading']")).getText();
		Assert.assertEquals(addressDeeletedMessage, "Address deleted");

	}

}
