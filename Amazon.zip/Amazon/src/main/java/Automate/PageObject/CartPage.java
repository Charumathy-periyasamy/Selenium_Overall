package Automate.PageObject;

public class CartPage {

}
