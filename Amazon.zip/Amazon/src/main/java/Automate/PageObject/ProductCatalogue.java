package Automate.PageObject;

public class ProductCatalogue {

}
