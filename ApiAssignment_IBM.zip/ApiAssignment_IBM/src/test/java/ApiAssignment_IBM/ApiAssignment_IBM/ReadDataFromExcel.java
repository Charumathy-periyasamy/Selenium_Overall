package ApiAssignment_IBM.ApiAssignment_IBM;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadDataFromExcel {
	
	public static void excelData() throws IOException
	{
	
	File f = new File("C:\\Users\\ELCOT\\Desktop\\APIAutomation_Assignment_IBM.xlsx");
	FileInputStream fis = new FileInputStream(f);
	
	XSSFWorkbook workbook = new XSSFWorkbook(fis);
	XSSFSheet sheet = workbook.getSheet("Sheet1");
sheet.getLastRowNum();

//	XSSFRow row = sheet.getRow(0);
	//XSSFCell cell = row.getCell(0);
	
	
//	String cellvalue = cell.getStringCellValue();

	
	}
}
