import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class dataDriven {

	public ArrayList<String> getData(String testCaseName) throws IOException {
		// TODO Auto-generated method stub
        ArrayList<String> arr = new ArrayList<String>();
		FileInputStream fis = new FileInputStream("C:\\Users\\ELCOT\\Documents\\testData.xlsx");
		XSSFWorkbook workBook = new XSSFWorkbook(fis);
		int sheetCount = workBook.getNumberOfSheets();
		
		for(int i=0;i<sheetCount;i++)
		{
			if(workBook.getSheetName(i).equals("data"))
			{
			XSSFSheet sheet =	workBook.getSheetAt(i);
			
		Iterator<Row>rows =sheet.rowIterator();
	Row row	=rows.next();
	Iterator<Cell> cells =  row.cellIterator();
	
	int k =0;
	int column = 0;
	while(cells.hasNext())	
	{
		
	 Cell cell	= cells.next();
	 if(cell.getStringCellValue().equals("TestCases"))
	 {
		 column=k;
	 }
	 
	k = k+1;
	 
	}
	System.out.println(column);
	
	while(rows.hasNext())
	{
	Row r =	rows.next();
	if(r.getCell(column).getStringCellValue().equals(testCaseName))
	{
	Iterator<Cell> cv=	r.cellIterator();
	while(cv.hasNext())
	{
	Cell v	= cv.next();
	
	if(v.getCellType() == CellType.STRING)
	{
	arr.add(v.getStringCellValue());
	}
	else
	{
	String s =	NumberToTextConverter.toText(v.getNumericCellValue());
	arr.add(s);

	}

	}
	

	}
	
	}
			
			}
		
		}
		return arr;
		
	}
	
	

}
