import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class excelTestNGintegration {
	
	DataFormatter formatter = new DataFormatter();
	
 @Test(dataProvider="getData")
public void testData(String t, String s, String o)
{
	System.out.println("t "+t);

	System.out.println("s "+s);
	System.out.println("o "+o);
}   
	
@DataProvider	
public 	Object[][] getData() throws IOException
{
	FileInputStream fis = new FileInputStream("C:\\Users\\ELCOT\\Documents\\testWorkBook.xlsx");
	XSSFWorkbook workBook = new XSSFWorkbook(fis);
XSSFSheet sheet =	workBook.getSheetAt(0);
int rowCount = sheet.getPhysicalNumberOfRows();
 XSSFRow row = sheet.getRow(0);
int columnCount = row.getLastCellNum();
System.out.println(columnCount);
System.out.println("rowcount" +rowCount);


Object dat[][] = new Object[rowCount-1][columnCount];

for(int i=0;i<rowCount-1;i++)
{
	XSSFRow r = sheet.getRow(i+1);
	for(int j=0;j<columnCount;j++)
	{
	XSSFCell c =	r.getCell(j);
 dat[i][j] =	formatter.formatCellValue(c);
System.out.println("data : "+ dat[i][j]);
	}
}


return dat;



}

}
