package ApiAssignment_IBM.ApiAssignment_IBM;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import io.restassured.response.Response;

/**
 * Unit test for simple App.
 */
public class MainClass 
{
    private static final Object[][] Object = null;
	/**
     * Rigorous Test :-)
     */
	String id = "19";
	String stringToDelete = "18";
	
    @Test(enabled = true)
    public void GetStudent()
    {
    	RestAssured.baseURI = "http://localhost:3000/student";
        String res = given().log().all().when().get().then().extract().response().asString();
        
        System.out.println("Response of get Student :" + res);
        
    }
    
    @Test(enabled = true)
    public void PostStudent()
    {
    	RestAssured.baseURI = "http://localhost:3000/student";
    	
   String PostResponse = 	given().log().all().header("Content-Type","application/json")
    	.body(RequestBody.postStudentPayload())
    	.when().post().then().log().all().extract().response().asString();
	
    }
    
   @Test(enabled = true)
   public void PutStudent()
   {
	   RestAssured.baseURI = "http://localhost:3000/student";
	   String PutResponse = given().log().all().header("Content-Type","application/json").queryParam("id", id)
			                .body(RequestBody.putStudentPayload())
			                .when().put()
			                .then().extract().response().asString();
	   
	   System.out.println("Put response body : " + PutResponse);
   }
   
   @Test(enabled = true)
   public void PatchStudent()
   {
	   RestAssured.baseURI = "http://localhost:3000/student";
	   String PatchResponse = given().log().all().header("Content-Type","application/json")
			                  .body("{\r\n"
			                  		+ "\"department\":\"EEE\"\r\n"
			                  		+ "}")
			                  .when().patch("/" + id)
			                  .then().log().all().assertThat().statusCode(200).extract().response().asString();
   }
   
   
   @Test(enabled = true)
   public void PutStudentUsingJson()
   {
	   RestAssured.baseURI = "http://localhost:3000/student";
	   String PutResponse = given().log().all().header("Content-Type","application/json")
			                .body(new File(System.getProperty("user.dir") + "\\testdata.json"))
			                .when().put("/2")
			                .then().log().all().extract().response().asString();
	   
	   System.out.println("Put response body : " + PutResponse);
  
   }
   
   
   @Test(enabled = true)
   public void PatchStudnetusingPojoandExcelAndJsonPath() throws IOException
   {
	   RestAssured.baseURI = "http://localhost:3000/student";
	  
	   String PatchResponse = given().log().all().header("Content-Type","application/json")
               .body(RequestBody.PatchUsingExcelAndPojo())
               .when().patch("/"+ id)
               .then().log().all().extract().response().asString();

System.out.println("Put response body : " + PatchResponse);

	}
   
  @Test(enabled = true)
  public void postUsingJsonfileAndJsonPath() throws IOException
  {
	  File filepath = new File(System.getProperty("user.dir") + "\\testdata.json");
	// TO read the json data into string
		
			String jsonData =	FileUtils.readFileToString(filepath);
			
			
		
        	 RestAssured.baseURI = "http://localhost:3000/student";
        	  	
        	   String PostResponse = 	given().log().all().header("Content-Type","application/json")
        	    	.body(jsonData)
        	    	.when().post().then().log().all().assertThat().statusCode(201).extract().response().asString();
			
        	   JsonPath js = new JsonPath(jsonData);
           	System.out.println(js.getList("courses"));	
  }
  

  @Test(enabled = true)
  public void PatchStudentHashMap()
  {
	   RestAssured.baseURI = "http://localhost:3000/student";
  	
	   String Response = 	given().log().all().header("Content-Type","application/json")
	    	.body(Payload_HashMap.hashMapPayload())
	    	.when().patch("/"+id).then().log().all().extract().response().asString();
	   
	   System.out.println("Response :" +Response);
		
  }
  
  @Test(enabled = true,dataProvider="getData")
  public void patchUsingDataProvider(int id)
  {
	  RestAssured.baseURI = "http://localhost:3000/student";
	  	
	   String Response = 	given().log().all().header("Content-Type","application/json")
	    	.body(" {\r\n"
	    			+ "        \"name\": \"test5\",\r\n"
	    			+ "        \"department\": \"it\",\r\n"
	    			+ "        \"id\": "+id+"\r\n"
	    			+ " }")
	    	.when().patch("/"+id).then().log().all().extract().response().asString();
	   
	   System.out.println("Response :" +Response);
	
  }
  
  
  

  @Test(enabled = true)
  public void ZDeleteStudent()
  {
	   RestAssured.baseURI = "http://localhost:3000/student";
	   given().log().all().when().delete("/" + stringToDelete).then().log().all().assertThat().statusCode(200);
  }
  
  
  
  @DataProvider (name = "getData")
  public Object[][] dataProvider()
  {
	  return new Object[][] {{1},{2}};
  }
  
  
  
    }

