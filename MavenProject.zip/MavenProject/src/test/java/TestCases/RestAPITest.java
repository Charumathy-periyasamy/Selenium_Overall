package TestCases;

import org.testng.annotations.Test;

public class RestAPITest {

	
	@Test
	public void RestAPITest1()
	{
		System.out.println("restapitest1");
	}
	
	@Test
	public void RestAPITest2()
	{
		System.out.println("restapitest2");
	}
	
}
