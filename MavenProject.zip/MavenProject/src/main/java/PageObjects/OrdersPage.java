package PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.ParentClass;

public class OrdersPage extends ParentClass

{
	WebDriver driver;

	public OrdersPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
@FindBy(xpath = "//tr[@class='ng-star-inserted']/th")
List<WebElement> orderedProductsList;
	
	
public boolean verifyTheOrderedProcuct(String orderId)
{
	System.out.println("orderid in verifymethod: " + orderId.split(" ")[1].trim());

boolean order =	orderedProductsList.stream().anyMatch(orderedProduct -> orderedProduct.getText().equals(orderId.split(" ")[1].trim()));
return order;

}

}
