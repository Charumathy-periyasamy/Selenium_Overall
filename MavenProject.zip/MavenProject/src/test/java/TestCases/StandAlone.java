package TestCases;

import java.time.Duration;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import PageObjects.LoadingPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StandAlone {
static WebDriver driver;
	static String ProductName;
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

	   ProductName = "ZARA COAT 3";
	//	WebDriverManager.chromedriver().setup();
	   System.setProperty("webdriver.chrome.driver","C:\\Users\\ELCOT\\chromedriver.exe");
	WebDriver	 driver = new ChromeDriver();
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));	
		driver.get("https://rahulshettyacademy.com/client");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@id=\"userEmail\"]")).sendKeys("myemail@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"userPassword\"]")).sendKeys("earthAa1@");
		driver.findElement(By.cssSelector("input#login")).click();
		LoadingPage loadingPage = new LoadingPage(driver);
		//Thread.sleep(5000);
	List<WebElement> Products =	driver.findElements(By.xpath("//div[@class='card-body']"));
	System.out.println(Products);
	
	/*
	 * for(WebElement f : Products) { String s =
	 * f.findElement(By.xpath("h5/b")).getText();
	 * 
	 * System.out.println(s); }
	 */
	WebElement filteredProduct = Products.stream().filter(product -> product.findElement(By.xpath("h5/b")).getText().equals(ProductName)).findFirst().orElse(null);
    	
  // click add to cart
	Thread.sleep(3000);
//	driver.findElement(By.xpath("//div[@class='card-body']/h5/b/parent::h5/parent::div/button[contains(text(),'Add To Cart')]")).click();
	
	filteredProduct.findElement(By.cssSelector(".card-body button:last-of-type")).click();
	
	// wait until buffer symbol go disappear
	
	wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(".ng-animating")));
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#toast-container")));
	driver.findElement(By.xpath("//button[@routerlink='/dashboard/cart']")).click();
	
	List<WebElement> cartProducts = driver.findElements(By.xpath("//div[@class='cartSection']/h3"));
	
boolean MatchedorNot =	cartProducts.stream().anyMatch(addedProduct -> addedProduct.getText().equals(ProductName));
System.out.println(MatchedorNot);	
Assert.assertTrue(MatchedorNot);


// click CheckOut button


driver.findElement(By.xpath("//button[@class='btn btn-primary'][contains(text(),'Checkout')]")).click();


/*
 * Actions a = new Actions(driver); // a.moveToElement(driver.findElement(By.
 * cssSelector("input[placeholder='Select Country']"))).sendKeys("India").build(
 * ).perform(); a.sendKeys(driver.findElement(By.
 * cssSelector("input[placeholder='Select Country']")),
 * "Inida").build().perform();
 * 
 * wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.
 * cssSelector("section[class='ta-results list-group ng-star-inserted']"))));
 * 
 * driver.findElement(By.cssSelector("button.ta-item:nth-of-type(2)")).click();
 * 
 */

driver.findElement(By.cssSelector("input[placeholder='Select Country']")).sendKeys("India");

Thread.sleep(6000);
 List<WebElement> listedOptions = driver.findElements(By.xpath("//button[@class='ta-item list-group-item ng-star-inserted']/span[contains(text(),' India')]"));

 System.out.println(listedOptions.get(1));


for(WebElement listedOption : listedOptions)
 {
	
	 if(listedOption.getText().contentEquals("India"))
	 {
		 System.out.println("Listeddoption : " + listedOption.getText());
		listedOption.click();
	 }
 }   
 // listedOptions.stream().anyMatch(listedOption -> listedOption.getText().contentEquals(" India"));
 
// click the place order button

JavascriptExecutor js = (JavascriptExecutor) driver;
js.executeScript("window.scrollBy(0,document.body.scrollHeight)", "");
Thread.sleep(4000);
driver.findElement(By.cssSelector("a[class='btnn action__submit ng-star-inserted']")).click();

driver.getCurrentUrl().contains("https://rahulshettyacademy.com/client/dashboard/thanks");	
Thread.sleep(2000);
String orderId = driver.findElement(By.xpath("//td[@class='box']/table/tbody/tr/td/table/tbody/tr[3]/td/label")).getText();

System.out.println("Order ID: " + orderId);

driver.close();
	}

}
