package PageObjects;

import java.util.List;

import org.testng.Assert;

import utilities.ParentClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CartPage extends ParentClass{

	WebDriver driver;
	
	public CartPage(WebDriver driver) {
	super(driver);
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	
@FindBy(xpath="//div[@class='cartSection']/h3")
List<WebElement> cartProducts;

@FindBy(xpath="//button[@class='btn btn-primary'][contains(text(),'Checkout')]")
WebElement checkOutButton;

	
public boolean verifyProductDisplay(String ProductName)
{
	
	boolean MatchedorNot =	cartProducts.stream().anyMatch(addedProduct -> addedProduct.getText().equals(ProductName));
	return MatchedorNot;
}

public CheckOutPage checkout()
{
	checkOutButton.click();
	CheckOutPage checkOutPage = new CheckOutPage(driver);
    return checkOutPage;
}

/* boolean MatchedorNot =	cartProducts.stream().anyMatch(addedProduct -> addedProduct.getText().equals(ProductName));
System.out.println(MatchedorNot);	
Assert.assertTrue(MatchedorNot);
*/

//click CheckOut button


//driver.findElement(By.xpath("//button[@class='btn btn-primary'][contains(text(),'Checkout')]")).click();

}
