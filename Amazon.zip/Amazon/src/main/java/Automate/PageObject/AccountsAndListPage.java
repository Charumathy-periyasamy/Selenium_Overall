package Automate.PageObject;

public class AccountsAndListPage {

}
