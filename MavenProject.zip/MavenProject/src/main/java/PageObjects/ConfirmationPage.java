package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.ParentClass;

public class ConfirmationPage extends ParentClass {

	WebDriver driver;
	
	


	public ConfirmationPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
@FindBy(xpath="//td[@class='box']/table/tbody/tr/td/table/tbody/tr[3]/td/label")
WebElement orderId;
	public String getOrderId() throws InterruptedException

	{
		Thread.sleep(2000);
		return orderId.getText();
	}
	

}
