package utilities;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import PageObjects.CartPage;
import PageObjects.OrdersPage;

public abstract class ParentClass {

	WebDriver driver;
	
	 public ParentClass(WebDriver driver) {
		this.driver = driver;
	}

	 @FindBy(xpath="//button[@routerlink='/dashboard/cart']")
	 WebElement cartButton;
     @FindBy(css = "button[routerlink='/dashboard/myorders']")
     WebElement OrdersButton;
	 
	 public void waitUntilTheElementToAppear(By findBy)
	 {
	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));	
	 wait.until(ExpectedConditions.visibilityOfElementLocated(findBy));
	 
	 }
	 
	 public void waitUnitilTheElementToDisapper(By findBy)
	 {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));	
		 wait.until(ExpectedConditions.invisibilityOfElementLocated(findBy));
	 }
	 
	 public CartPage clickCart()
		{
			cartButton.click();
			CartPage cartPage = new CartPage(driver);
			return cartPage;
		}
	 
	 public OrdersPage goToOrderesPage()
	 {
		 OrdersButton.click();
		 OrdersPage ordersPage = new OrdersPage(driver);
		 return ordersPage;
	 }
	 
	 public void close()
	 {
		 driver.close();
	 }
	
}
