package TestCases;

import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PageObjects.CartPage;
import PageObjects.CheckOutPage;
import PageObjects.ConfirmationPage;
import PageObjects.LoadingPage;
import PageObjects.OrdersPage;
import PageObjects.ProductCatalogue;
import TestComponent.BasePage;
import TestComponent.Retry;

import io.github.bonigarcia.wdm.WebDriverManager;

public class StandAloneTest extends BasePage {

	public ProductCatalogue productCatalogue;
	public CheckOutPage checkOutPage;
	public ConfirmationPage  confirmationPage;
	public OrdersPage ordersPage;
	
	public String orderId;
	
	
	@Test(dataProvider = "getData" , retryAnalyzer = Retry.class)
	public void submitOrder(HashMap<String, String>  input) throws InterruptedException, IOException
	{

		 productCatalogue =	loadingPage.action(input.get("email"), input.get("password"));
		 WebElement filteredProduct = 	 productCatalogue.getProductByName(input.get("productName"));
	productCatalogue.addToCart(input.get("productName"));
	CartPage cartPage =	productCatalogue.clickCart();
	boolean cartProduct = cartPage.verifyProductDisplay(input.get("productName"));
	Assert.assertTrue(false);
	
	 checkOutPage = cartPage.checkout();
	checkOutPage.selectCountryInDropdown("India");
	 confirmationPage =	checkOutPage.clickPlaceOrder();
  orderId =	confirmationPage.getOrderId();
	//String orderId = driver.findElement(By.xpath("//td[@class='box']/table/tbody/tr/td/table/tbody/tr[3]/td/label")).getText();

System.out.println("Order ID: " + orderId);
System.out.println("split using | 0:" + orderId.split(" ")[1].trim());

tearDown();


	}
	
	
	
	@Test(dependsOnMethods= {"submitOrder"})
	public void orderPageValidation() throws InterruptedException
	{
		 productCatalogue =	loadingPage.action("myemail@gmail.com", "earthAa1@");
			System.out.println("inside OrderPageValidationTest");
		
			Thread.sleep(5000);
		
 ordersPage = productCatalogue.goToOrderesPage();	
 boolean orderResult = ordersPage.verifyTheOrderedProcuct(orderId);
 System.out.println("order Result : "+ orderResult);
 //Assert.assertTrue(orderResult);
 System.out.println("SUCCESSS");
	}

/*
	
@DataProvider
public Object[][] getData()
{
	
	
	return new Object[][] {{"myemail@gmail.com","earthAa1@","ZARA COAT 3"},{"testdatauser@gmail.com","earthAa1@","ZARA COAT 3"}} ;
}
*/
	
	
	
@DataProvider

public Object[][] getData() throws IOException
{
	
	List<HashMap<String, String>> inputData = getJsonDataToMap(System.getProperty("user.dir") + "\\src\\test\\java\\TestData\\PurchaseOrder.json");
	return new Object[][] {{inputData.get(0)},{inputData.get(1)}};
}
	
}
