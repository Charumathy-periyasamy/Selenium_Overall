package TestComponent;

import java.io.IOException;


import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.*;

import Resources.ExtentReporterNG;

public class TestNGListerners extends BasePage implements ITestListener {

	ExtentTest extentTest;
	ExtentReports	test =   ExtentReporterNG.ExtentReportsData();
	
@Override
public void onTestStart(ITestResult iTestResult) {
    System.out.println("onTestStart");
    test.createTest(iTestResult.getMethod().getMethodName());
}

@Override
public void onTestSuccess(ITestResult iTestResult) {
    System.out.println("onTestSuccess");
    extentTest.log(Status.PASS, "Passed");
   
 
 // since you need the driver in your screenshot method do this:
    WebDriver driver = ((BasePage)iTestResult.getInstance()).driver;
          System.out.println("abskdlgilojlkn" + driver);
          try {
        String	  filePath=	takeScreenshot(iTestResult.getMethod().getMethodName(), driver);
      // extentTest.addScreenCaptureFromPath(filePath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
      
    //      extentTest.addScreenCaptureFromPath(filePath, iTestResult.getMethod().getMethodName());
 
 }

@Override
public void onTestFailure(ITestResult iTestResult) {
    System.out.println("onTestFailure");
            
    
  // since you need the driver in your screenshot method do this:
    WebDriver driver = ((BasePage)iTestResult.getInstance()).driver;
          System.out.println("abskdlgilojlkn" + driver);
          try {
        	  String	  filePath=	takeScreenshot(iTestResult.getMethod().getMethodName(), driver);
        //	  extentTest.addScreenCaptureFromPath(filePath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
    
   //       extentTest.addScreenCaptureFromPath(filePath, iTestResult.getMethod().getMethodName());
}

@Override
public void onTestSkipped(ITestResult iTestResult) {
    System.out.println("onTestSkipped");
}

@Override
public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {
    System.out.println("onTestFailedButWithinSuccessPercentage");
}

@Override
public void onFinish(ITestContext iTestContext) {
    System.out.println("onFinish");
    
    test.flush();
}

}
