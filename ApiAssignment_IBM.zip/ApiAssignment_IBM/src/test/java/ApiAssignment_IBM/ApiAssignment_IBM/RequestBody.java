package ApiAssignment_IBM.ApiAssignment_IBM;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.SheetBuilder;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.path.json.JsonPath;

public class RequestBody {

	static int id =20;
	static String deptToChange = "CS";
	static String courseTitle = "API";
	static String toCourse="Appium";
	public static String postStudentPayload()
	{
		
		return " {\r\n"
				+ "        \"name\": \"test5\",\r\n"
				+ "        \"department\": \"it\",\r\n"
				+ "        \"id\": "+id+",\r\n"
				+ "        \"courses\": [\r\n"
				+ "            {\r\n"
				+ "                \"title\": \"Selenium Python\",\r\n"
				+ "                \"mark\": 50\r\n"
				+ "            },\r\n"
				+ "            {\r\n"
				+ "                \"title\": \"API\",\r\n"
				+ "                \"mark\": 40\r\n"
				+ "            },\r\n"
				+ "            {\r\n"
				+ "                \"title\": \"Mobiletesting\",\r\n"
				+ "                \"mark\": 45\r\n"
				+ "            }\r\n"
				+ "        ],\r\n"
				+ "        \"othercourses\": [\r\n"
				+ "            \"Java\",\r\n"
				+ "            \".Net\",\r\n"
				+ "            \"Ruby\"\r\n"
				+ "        ]\r\n"
				+ "    }";
	}
	
	public static String putStudentPayload()
	{
		return " {\r\n"
				+ "        \"name\": \"test5\",\r\n"
				+ "        \"department\": \""+deptToChange+"\",\r\n"
				+ "        \"id\": "+id+",\r\n"
				+ "        \"courses\": [\r\n"
				+ "            {\r\n"
				+ "                \"title\": \"Selenium Python\",\r\n"
				+ "                \"mark\": 50\r\n"
				+ "            },\r\n"
				+ "            {\r\n"
				+ "                \"title\": \"API\",\r\n"
				+ "                \"mark\": 40\r\n"
				+ "            },\r\n"
				+ "            {\r\n"
				+ "                \"title\": \"Mobiletesting\",\r\n"
				+ "                \"mark\": 45\r\n"
				+ "            }\r\n"
				+ "        ],\r\n"
				+ "        \"othercourses\": [\r\n"
				+ "            \"Java\",\r\n"
				+ "            \".Net\",\r\n"
				+ "            \"Ruby\"\r\n"
				+ "        ]\r\n"
				+ "    }";
	}
	
	
	public static String  PatchUsingExcelAndPojo() throws IOException
	{
		File f = new File("C:\\Users\\ELCOT\\Desktop\\APIAutomation_Assignment_IBM.xlsx");
		FileInputStream fis = new FileInputStream(f);
		pojo po = new pojo();
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("Sheet1");
		XSSFRow row1 = sheet.getRow(0); 
		XSSFCell cell = row1.getCell(0);
System.out.println(sheet.getRow(4).getCell(0));  
		for(int i =0;i<sheet.getLastRowNum();i++)
		{
			
			String cellvalue = sheet.getRow(i).getCell(0).getStringCellValue().toString();
			 System.out.println("cellvalue : "+ cellvalue);
				System.out.println(sheet.getRow(i).getRowNum());
 	 
 Iterator<Cell> cell1 = sheet.getRow(i).cellIterator();
        if(cellvalue.equals("courses"))
        {
          
       	cell1.next();
       	
       	for(int j=i;j>=i;j++)
       	{
       		try
       		{
       		
     XSSFRow row2 =	sheet.getRow(j);
  //   Iterator<Cell> cell2 = row2.cellIterator();
     
       XSSFCell cell3 = row2.getCell(1);
       		if(cell3.getStringCellValue().equals("title"))
       		{
       			//po.setTitle(toCourse);
       			System.out.println("insidet title");
       		if(row2.getCell(2).getStringCellValue().equals("Appium"))
       			
       		{
       			System.out.println("success");
       			String res = row2.getCell(2).getStringCellValue().toString();
       			po.setTitle(res);
       			break;
       		}
       		else
       		{
      			j++;
       		continue;
       			
       		}
       		}
       		
       	}
       		catch(NullPointerException NPE)
       		{
       		NPE.printStackTrace();
       	}
        }
       

 break;
		}
        else
        {
        	System.out.println("Inside first else statement"); 
     
        
        	continue;
        }

		}

		ObjectMapper obm = new ObjectMapper();
		String jsonstringdata =   obm.writeValueAsString(po);
		
		JsonPath js = new JsonPath(jsonstringdata);
		
		return " {\r\n"
		+ "       \r\n"
		+ "        \"courses\": [\r\n"
		+ "           {\r\n"
		+ "                \"title\": \"Selenium P\",\r\n"
		+ "                \"mark\": 50\r\n"
		+ "            },\r\n"
		+ "            {\r\n"
		+ "                \"title\": \""+js.get("title")+"\",\r\n"
		+ "                \"mark\": 40\r\n"
		+ "            },\r\n"
		+ "            {\r\n"
		+ "                \"title\": \"Mobiletesting\",\r\n"
		+ "                \"mark\": 45\r\n"
		+ "            }        ]\r\n"
		+ "      \r\n"
		+ "    }";    

		
}

}