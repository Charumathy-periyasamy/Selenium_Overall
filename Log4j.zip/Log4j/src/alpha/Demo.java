package alpha;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Demo {

	
   private static Logger log = LogManager.getLogger(Demo.class.getName());
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	log.info("info log demo");
	log.debug("debug log demo");
	log.error("error log demo");
	log.fatal("fatal lof demo");
	

	log.info("info log demo");
	log.debug("debug log demo");
	log.error("error log demo");
	log.fatal("fatal lof demo");
	
	

	log.info("info log demo");
	log.debug("debug log demo");
	log.error("error log demo");
	log.fatal("fatal lof demo");
	

	log.info("info log demo");
	log.debug("debug log demo");
	log.error("error log demo");
	log.fatal("fatal lof demo");
	

	log.info("info log demo");
	log.debug("debug log demo");
	log.error("error log demo");
	log.fatal("fatal lof demo");
	

	log.info("info log demo");
	log.debug("debug log demo");
	log.error("error log demo");
	log.fatal("fatal lof demo");
	

	log.info("info log demo");
	log.debug("debug log demo");
	log.error("error log demo");
	log.fatal("fatal lof demo");
	

	log.info("info log demo");
	log.debug("debug log demo");
	log.error("error log demo");
	log.fatal("fatal lof demo");

	log.info("info log demo");
	log.debug("debug log demo");
	log.error("error log demo");
	log.fatal("fatal lof demo");

	log.info("info log demo");
	log.debug("debug log demo");
	log.error("error log demo");
	log.fatal("fatal lof demo");
	
	
	
	
	}

}
