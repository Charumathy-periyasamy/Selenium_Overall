package Automate.PageObject;

public class LandingPage {
	
	
	

@FindBy()	

}
